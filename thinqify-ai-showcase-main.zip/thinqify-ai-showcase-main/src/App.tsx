import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

// English Pages
import HomeEN from "./pages/en/Home";
import ServicesEN from "./pages/en/Services";
import IndustriesEN from "./pages/en/Industries";
import PricingEN from "./pages/en/Pricing";
import AboutEN from "./pages/en/About";
import FAQEN from "./pages/en/FAQ";

// Service Detail Pages (EN)
import OutreachEN from "./pages/en/services/Outreach";
import ChatbotEN from "./pages/en/services/Chatbot";
import VoiceEN from "./pages/en/services/Voice";
import SocialEN from "./pages/en/services/Social";
import LeadsEN from "./pages/en/services/Leads";
import PackagesEN from "./pages/en/services/Packages";

// French Pages
import HomeFR from "./pages/fr/Home";
import ServicesFR from "./pages/fr/Services";
import IndustriesFR from "./pages/fr/Industries";
import PricingFR from "./pages/fr/Pricing";
import AboutFR from "./pages/fr/About";
import FAQFR from "./pages/fr/FAQ";

// Service Detail Pages (FR)
import OutreachFR from "./pages/fr/services/Outreach";
import ChatbotFR from "./pages/fr/services/Chatbot";
import VoiceFR from "./pages/fr/services/Voice";
import SocialFR from "./pages/fr/services/Social";
import LeadsFR from "./pages/fr/services/Leads";
import PackagesFR from "./pages/fr/services/Packages";

import NotFound from "./pages/NotFound";
import ScrollToTop from "./components/ScrollToTop";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <ScrollToTop />
        <Routes>
          {/* Redirect root to English */}
          <Route path="/" element={<Navigate to="/en" replace />} />

          {/* English Routes */}
          <Route path="/en" element={<HomeEN />} />
          <Route path="/en/services" element={<ServicesEN />} />
          <Route path="/en/services/outreach" element={<OutreachEN />} />
          <Route path="/en/services/chatbot" element={<ChatbotEN />} />
          <Route path="/en/services/voice" element={<VoiceEN />} />
          <Route path="/en/services/social" element={<SocialEN />} />
          <Route path="/en/services/leads" element={<LeadsEN />} />
          <Route path="/en/services/packages" element={<PackagesEN />} />
          <Route path="/en/industries" element={<IndustriesEN />} />
          <Route path="/en/engagement-maintenance" element={<PricingEN />} />
          <Route path="/en/about" element={<AboutEN />} />
          <Route path="/en/faq" element={<FAQEN />} />

          {/* French Routes */}
          <Route path="/fr" element={<HomeFR />} />
          <Route path="/fr/services" element={<ServicesFR />} />
          <Route path="/fr/services/outreach" element={<OutreachFR />} />
          <Route path="/fr/services/chatbot" element={<ChatbotFR />} />
          <Route path="/fr/services/voice" element={<VoiceFR />} />
          <Route path="/fr/services/social" element={<SocialFR />} />
          <Route path="/fr/services/leads" element={<LeadsFR />} />
          <Route path="/fr/services/packages" element={<PackagesFR />} />
          <Route path="/fr/industries" element={<IndustriesFR />} />
          <Route path="/fr/engagement-maintenance" element={<PricingFR />} />
          <Route path="/fr/about" element={<AboutFR />} />
          <Route path="/fr/faq" element={<FAQFR />} />

          {/* 404 */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
