import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';

import { useScrollReveal } from '@/hooks/useScrollReveal';
import { Rocket, RefreshCw, Server, Wrench, TrendingUp, Shield, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Pricing = () => {
  useScrollReveal();

  useEffect(() => {
    document.documentElement.lang = 'fr';
  }, []);

  const engagementModels = [
    {
      icon: Rocket,
      title: 'Projet Unique',
      tagline: 'Construire & Livrer',
      description: 'Portée fixe avec livrables clairs.',
      includes: [
        'Portée et calendrier de projet définis',
        'Jalons de livrables clairs',
        'Formation et documentation incluses',
        'Période de support post-lancement',
        'Transfert de connaissances à votre équipe',
      ],
      bestFor: 'Entreprises avec des ressources techniques internes prêtes à prendre le relais.',
    },
    {
      icon: RefreshCw,
      title: 'Abonnement Mensuel',
      tagline: 'Construire & Maintenir',
      description: 'Mises à jour et améliorations continues dans des limites définies.',
      includes: [
        'Fenêtres de maintenance mensuelles',
        'Améliorations et mises à jour de fonctionnalités',
        'Surveillance des performances',
        'Corrections de bugs et optimisations',
        'Examens stratégiques réguliers',
      ],
      bestFor: 'Organisations souhaitant une amélioration continue tout en conservant le contrôle opérationnel.',
    },
    {
      icon: Server,
      title: 'Entièrement Géré & Hébergé',
      tagline: 'Maintenir, Améliorer & Héberger',
      description: 'Nous opérons la pile complète pour vous selon des termes fixes ou basés sur l\'utilisation.',
      includes: [
        'Gestion opérationnelle complète',
        'Hébergement et surveillance de l\'infrastructure',
        'Optimisation continue',
        'Résolution proactive des problèmes',
        'Équipe de support dédiée',
        'Rapports de performance réguliers',
      ],
      bestFor: 'Clients recherchant une solution sans intervention avec disponibilité et performance garanties.',
    },
  ];

  const maintenanceTiers = [
    {
      icon: Wrench,
      title: 'Maintenance de Base',
      description: 'Corrections de bugs et surveillance de la disponibilité.',
      includes: [
        'Corrections de bugs critiques',
        'Correctifs de sécurité',
        'Surveillance de la disponibilité',
        'Support de base pendant les heures ouvrables',
      ],
    },
    {
      icon: TrendingUp,
      title: 'Maintenance + Amélioration',
      description: 'Corrections plus améliorations planifiées.',
      includes: [
        'Toutes les fonctionnalités de Maintenance de Base',
        'Améliorations mensuelles des fonctionnalités',
        'Optimisations de performance',
        'Support prioritaire',
        'Sessions stratégiques trimestrielles',
      ],
    },
    {
      icon: Shield,
      title: 'Maintenir, Améliorer & Héberger',
      description: 'Maintenance entièrement gérée tout-en-un.',
      includes: [
        'Toutes les fonctionnalités Maintenance + Amélioration',
        'Gestion de l\'infrastructure',
        'Surveillance proactive et alertes',
        'Support 24/7',
        'Gestionnaire de compte dédié',
      ],
    },
  ];

  return (
    <div className="min-h-screen">
        <Header lang="fr" />
        <main className="container mx-auto px-4 pt-32 pb-24">
          {/* Hero Section */}
          <div className="text-center mb-20 scroll-reveal">
            <h1 className="text-5xl font-heading font-bold uppercase mb-4">
              Engagement & <span className="text-primary">Maintenance</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Modèles d'engagement flexibles conçus pour s'adapter à vos besoins opérationnels et capacités techniques.
            </p>
          </div>

          {/* Engagement Models Section */}
          <section className="mb-24">
            <h2 className="text-3xl font-heading font-bold uppercase text-center mb-12 scroll-reveal">
              Modèles d'Engagement
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {engagementModels.map((model, index) => {
                const IconComponent = model.icon;
                return (
                  <div
                    key={model.title}
                    className="bg-card p-8 rounded-2xl border border-border card-hover-effect scroll-reveal"
                    style={{ animationDelay: `${index * 80}ms` }}
                  >
                    <IconComponent className="w-12 h-12 text-primary mb-4" />
                    <h3 className="text-2xl font-heading font-bold uppercase mb-2 hover-text">{model.title}</h3>
                    <p className="text-primary font-semibold mb-3">{model.tagline}</p>
                    <p className="text-muted-foreground mb-6">{model.description}</p>
                    
                    <div className="mb-6">
                      <p className="font-semibold mb-3 uppercase text-sm">Inclut:</p>
                      <ul className="space-y-2">
                        {model.includes.map((item) => (
                          <li key={item} className="flex items-start gap-2">
                            <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                            <span className="text-sm">{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    <p className="text-sm italic text-muted-foreground border-t border-border pt-4">
                      <span className="font-semibold not-italic">Idéal pour:</span> {model.bestFor}
                    </p>
                  </div>
                );
              })}
            </div>
          </section>

          {/* Maintenance Tiers Section */}
          <section className="mb-24">
            <h2 className="text-3xl font-heading font-bold uppercase text-center mb-12 scroll-reveal">
              Niveaux de Maintenance
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {maintenanceTiers.map((tier, index) => {
                const IconComponent = tier.icon;
                return (
                  <div
                    key={tier.title}
                    className="bg-card p-8 rounded-2xl border border-border card-hover-effect scroll-reveal"
                    style={{ animationDelay: `${index * 80}ms` }}
                  >
                    <IconComponent className="w-12 h-12 text-primary mb-4" />
                    <h3 className="text-2xl font-heading font-bold uppercase mb-2 hover-text">{tier.title}</h3>
                    <p className="text-muted-foreground mb-6">{tier.description}</p>
                    
                    <div>
                      <p className="font-semibold mb-3 uppercase text-sm">Inclut:</p>
                      <ul className="space-y-2">
                        {tier.includes.map((item) => (
                          <li key={item} className="flex items-start gap-2">
                            <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                            <span className="text-sm">{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          {/* CTA Footer */}
          <div className="text-center scroll-reveal">
            <p className="text-xl mb-6">Prêt à explorer comment nous pouvons travailler ensemble?</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link to="/fr/services">
                <Button size="lg" className="min-w-[200px]">
                  Explorer les Services
                </Button>
              </Link>
              <Link to="/fr/about">
                <Button size="lg" variant="outline" className="min-w-[200px]">
                  À Propos de Thinqify
                </Button>
              </Link>
            </div>
          </div>
        </main>
        <Footer lang="fr" />
      </div>
  );
};

export default Pricing;
