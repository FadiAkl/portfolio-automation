import { useEffect } from 'react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';

import { useScrollReveal } from '@/hooks/useScrollReveal';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const FAQ = () => {
  useScrollReveal();

  useEffect(() => {
    document.documentElement.lang = 'fr';
  }, []);

  const faqs = [
    {
      question: 'Quelles langues supportez-vous ?',
      answer:
        "Toutes les langues. Les systèmes IA de Thinqify communiquent dans n'importe quelle langue configurée par le client. Nous pouvons mettre en place un support multilingue pour vos besoins spécifiques.",
    },
    {
      question: 'Comment Thinqify gère-t-il la confidentialité des données ?',
      answer:
        'Nous suivons les normes RGPD et internationales. Les données restent cryptées et isolées par client. Nous ne partageons jamais vos données avec des tiers, et vous maintenez le contrôle total de vos informations.',
    },
    {
      question: 'Avec quels outils ou plateformes vos systèmes peuvent-ils s\'intégrer ?',
      answer:
        'CRM (Salesforce, HubSpot), sites web, calendriers (Google Calendar, Outlook), plateformes de chat (WhatsApp, Messenger) et canaux sociaux (Instagram, Facebook). Nous pouvons également créer des intégrations personnalisées pour vos outils spécifiques.',
    },
    {
      question: 'Ai-je besoin de compétences techniques pour utiliser Thinqify ?',
      answer:
        'Non. Les solutions sont clés en main et gérées, ne nécessitant aucun codage. Nous gérons tous les aspects techniques et fournissons une interface simple pour gérer vos systèmes d\'automatisation.',
    },
    {
      question: 'Comment les mises à jour ou les problèmes sont-ils gérés ?',
      answer:
        'Selon votre plan de maintenance, Thinqify fournit des corrections de bugs, des améliorations ou un hébergement complet. Nous surveillons les systèmes 24h/24 et 7j/7 et traitons proactivement les problèmes avant qu\'ils n\'impactent vos opérations.',
    },
    {
      question: 'Quelles industries peuvent en bénéficier le plus ?',
      answer:
        'Éducation, Immobilier, Santé, Commerce Électronique, Services Professionnels, et plus encore. Toute entreprise avec des communications répétitives, de la planification ou des tâches de collecte de données peut bénéficier de l\'automatisation.',
    },
    {
      question: 'Comment puis-je commencer ?',
      answer:
        'Contactez-nous à Fadi@thinqify.com pour une consultation. Nous analysons vos besoins, proposons une portée et un calendrier, et déployons le système. La plupart des implémentations sont terminées dans les 2-4 semaines.',
    },
  ];

  return (
    <div className="min-h-screen">
        <Header lang="fr" />
        <main className="container mx-auto px-4 py-16">
          <h1 className="text-5xl font-heading font-bold uppercase text-center mb-4 mt-8 scroll-reveal">
            Questions <span className="text-primary">Fréquemment Posées</span>
          </h1>
          <div className="max-w-3xl mx-auto mt-12">
            <Accordion type="single" collapsible className="space-y-4">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`} className="scroll-reveal">
                  <AccordionTrigger className="text-left font-heading font-semibold text-lg">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </main>
        <Footer lang="fr" />
      </div>
  );
};

export default FAQ;
