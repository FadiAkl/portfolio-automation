import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, Phone, Mail, Share2, Database, Package, GraduationCap, Building2, Heart, ShoppingCart, Briefcase, Shield, Gauge, Eye } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import ServiceCard from '@/components/ui/service-card';

import HeroGradient from '@/components/effects/HeroGradient';
import { useScrollReveal } from '@/hooks/useScrollReveal';
import { Button } from '@/components/ui/button';

const Home = () => {
  useScrollReveal();

  useEffect(() => {
    document.documentElement.lang = 'fr';
  }, []);

  const services = [
    {
      title: 'Système de Prospection Automatisé',
      icon: Mail,
      shortDescription: 'Personnalisé à grande échelle depuis vos listes de leads.',
      href: '/fr/services/outreach',
    },
    {
      title: 'Chatbot IA',
      icon: MessageSquare,
      shortDescription: 'Réponses 24/7, réservations et ventes guidées.',
      href: '/fr/services/chatbot',
    },
    {
      title: 'Assistant Vocal IA',
      icon: Phone,
      shortDescription: 'Répond à chaque appel. Planifie instantanément.',
      href: '/fr/services/voice',
    },
    {
      title: 'Automatisation des Réseaux Sociaux',
      icon: Share2,
      shortDescription: 'Réponse automatique aux DMs et acheminement des leads chauds.',
      href: '/fr/services/social',
    },
    {
      title: 'Collection Automatisée de Leads',
      icon: Database,
      shortDescription: 'Listes ciblées avec rôles, emails, téléphones.',
      href: '/fr/services/leads',
    },
    {
      title: 'Forfaits IA Intégrés',
      icon: Package,
      shortDescription: 'Piles prêtes pour l\'industrie qui fonctionnent.',
      href: '/fr/services/packages',
    },
  ];

  return (
    <div className="min-h-screen">
        <Header lang="fr" />
        <main className="pt-16">
          {/* Hero Section */}
          <section className="relative container mx-auto px-4 overflow-hidden" style={{ paddingTop: '20vh', paddingBottom: '10vh' }}>
            <HeroGradient />
            <div className="relative z-10 text-center" style={{ paddingTop: '10vh', paddingBottom: '10vh' }}>
              <h1 className="text-5xl md:text-7xl font-heading font-bold uppercase mb-6 scroll-reveal">
                IA, intégrée.
                <br />
                <span className="text-primary">Résultats, automatisés.</span>
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto scroll-reveal">
                Chat, voix, prospection, prospects et réseaux sociaux — conçus pour gérer vos opérations à grande échelle.
              </p>
              <div className="scroll-reveal">
                <Button asChild size="lg" className="text-lg px-8 py-6">
                  <Link to="/fr/services">Explorer les Services</Link>
                </Button>
              </div>
            </div>
          </section>

          {/* Industries We Serve - Inline Emoji Row */}
          <section className="bg-background py-24">
            <div className="container mx-auto px-4">
              <div className="text-center mb-12">
                <h2 className="text-4xl font-heading font-bold uppercase mb-8 scroll-reveal">
                  Secteurs Que Nous Servons
                </h2>
              </div>
              <div className="flex justify-center items-center gap-12 flex-wrap max-w-5xl mx-auto">
                {[
                  { emoji: '🎓', label: 'Éducation', anchor: 'education' },
                  { emoji: '🏢', label: 'Immobilier', anchor: 'real-estate' },
                  { emoji: '⚕️', label: 'Santé', anchor: 'healthcare' },
                  { emoji: '🛒', label: 'E-commerce', anchor: 'ecommerce' },
                  { emoji: '💼', label: 'Services Professionnels', anchor: 'professional-services' },
                ].map((industry, index) => (
                  <Link
                    key={industry.label}
                    to={`/fr/industries#${industry.anchor}`}
                    className="flex flex-col items-center justify-center min-w-[100px] min-h-[100px] cursor-pointer group scroll-reveal transition-all duration-200 hover:scale-105 focus:outline-2 focus:outline-primary active:scale-95 active:shadow-[0_0_20px_rgba(0,206,209,0.4)]"
                    style={{ animationDelay: `${index * 100}ms` }}
                    aria-label={`Aller à la section ${industry.label}`}
                  >
                    <span className="text-6xl mb-2">{industry.emoji}</span>
                    <p className="text-lg font-semibold text-foreground text-center transition-colors duration-200 group-hover:text-primary">
                      {industry.label}
                    </p>
                  </Link>
                ))}
              </div>
            </div>
          </section>

          {/* Services Overview */}
          <section className="container mx-auto px-4 py-24">
            <div className="text-center mb-16 scroll-reveal">
              <h2 className="text-4xl font-heading font-bold uppercase mb-4">
                Nos Services
              </h2>
              <p className="text-lg" style={{ color: '#666666' }}>
                Solutions complètes d'automatisation IA pour les entreprises modernes.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
              {services.map((service, index) => {
                const IconComponent = service.icon;
                return (
                  <Link
                    key={service.title}
                    to={service.href}
                    className="group bg-white p-8 rounded-2xl border border-border shadow-[0_4px_12px_rgba(0,0,0,0.05)] hover:shadow-[0_4px_16px_rgba(0,206,209,0.25)] service-card-hop active:scale-[0.97] scroll-reveal flex items-start gap-4 focus:outline-2 focus:outline-primary focus:ring-2 focus:ring-primary transition-transform duration-150"
                    style={{ animationDelay: `${index * 100}ms` }}
                    aria-label={`En savoir plus sur ${service.title}`}
                  >
                    <div className="flex-shrink-0">
                      <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center">
                        <IconComponent className="w-8 h-8 text-primary" strokeWidth={1.5} />
                      </div>
                    </div>
                    <div className="flex-1 min-w-0 pt-1">
                      <h3 className="font-heading font-bold text-lg mb-1 text-foreground group-hover:text-primary transition-colors duration-200">{service.title}</h3>
                      <p className="text-sm line-clamp-1" style={{ color: '#666666' }}>{service.shortDescription}</p>
                    </div>
                    <div className="flex-shrink-0 text-primary group-hover:translate-x-1 transition-transform duration-200 pt-1">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </div>
                  </Link>
                );
              })}
            </div>
          </section>

          {/* Core Values */}
          <section className="container mx-auto px-4 py-16">
            <h2 className="text-4xl font-heading font-bold uppercase text-center mb-12 scroll-reveal">
              Nos Valeurs Fondamentales
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              <div className="bg-card p-8 rounded-2xl border border-border shadow-sm card-hover-effect scroll-reveal">
                <div className="flex justify-center mb-4">
                  <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center">
                    <Shield className="w-7 h-7 text-primary" strokeWidth={1.5} />
                  </div>
                </div>
                <h3 className="text-xl font-heading font-bold uppercase mb-3 text-center hover-text">Confidentialité</h3>
                <p className="text-muted-foreground text-center">
                  Nous protégeons les données et concevons pour la conformité par défaut.
                </p>
              </div>
              <div className="bg-card p-8 rounded-2xl border border-border shadow-sm card-hover-effect scroll-reveal">
                <div className="flex justify-center mb-4">
                  <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center">
                    <Gauge className="w-7 h-7 text-primary" strokeWidth={1.5} />
                  </div>
                </div>
                <h3 className="text-xl font-heading font-bold uppercase mb-3 text-center hover-text">Performance</h3>
                <p className="text-muted-foreground text-center">
                  Systèmes rapides et évolutifs avec disponibilité et latence mesurables.
                </p>
              </div>
              <div className="bg-card p-8 rounded-2xl border border-border shadow-sm card-hover-effect scroll-reveal">
                <div className="flex justify-center mb-4">
                  <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center">
                    <Eye className="w-7 h-7 text-primary" strokeWidth={1.5} />
                  </div>
                </div>
                <h3 className="text-xl font-heading font-bold uppercase mb-3 text-center hover-text">Clarté</h3>
                <p className="text-muted-foreground text-center">
                  Logique transparente, transfert propre, contrôles simples.
                </p>
              </div>
            </div>
          </section>
        </main>
        <Footer lang="fr" />
      </div>
  );
};

export default Home;
