import { useEffect } from 'react';
import { GraduationCap, Home as HomeIcon, Heart, ShoppingBag, Briefcase, AlertCircle, CheckCircle2, Wrench } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';

import { useScrollReveal } from '@/hooks/useScrollReveal';

const Industries = () => {
  useScrollReveal();

  useEffect(() => {
    document.documentElement.lang = 'fr';
  }, []);

  const industries = [
    {
      id: 'education',
      name: 'Éducation',
      icon: GraduationCap,
      painPoints: [
        'Volume élevé de demandes étudiantes répétitives',
        'Processus d\'inscription et d\'enregistrement manuels',
        'Heures de support limitées pour parents et étudiants',
      ],
      proposedStack: ['Chatbot IA', 'Prospection Automatisée', 'Assistant Vocal'],
      outcomes: [
        'Réduction de 60% de la charge administrative',
        'Engagement et satisfaction étudiante améliorés',
        'Support disponible 24h/24',
      ],
    },
    {
      id: 'real-estate',
      name: 'Immobilier',
      icon: HomeIcon,
      painPoints: [
        'Qualification chronophage des prospects',
        'Conflits de planification pour visites de propriétés',
        'Suivi client inefficace',
      ],
      proposedStack: ['Collecte de Prospects', 'Prospection Automatisée', 'Automatisation Réseaux Sociaux'],
      outcomes: [
        'Plus de prospects qualifiés dans le pipeline',
        'Planification efficace des visites',
        'Communication client cohérente',
      ],
    },
    {
      id: 'healthcare',
      name: 'Santé et Cliniques',
      icon: Heart,
      painPoints: [
        'Taux d\'absence élevés aux rendez-vous',
        'Volume d\'appels téléphoniques écrasant',
        'Réservation et rappels de rendez-vous manuels',
      ],
      proposedStack: ['Assistant Vocal IA', 'Chatbot IA', 'Prospection Automatisée'],
      outcomes: [
        'Réduction de 40% des absences',
        'Meilleure expérience patient',
        'Communications automatisées conformes HIPAA',
      ],
    },
    {
      id: 'ecommerce',
      name: 'Commerce Électronique',
      icon: ShoppingBag,
      painPoints: [
        'Volume élevé de tickets de support client',
        'Réponses retardées aux demandes de commande',
        'Capacité d\'engagement limitée sur réseaux sociaux',
      ],
      proposedStack: ['Chatbot IA', 'Automatisation Réseaux Sociaux', 'Prospection Automatisée'],
      outcomes: [
        'Augmentation des scores de satisfaction client',
        'Taux de conversion de ventes plus élevés',
        'Support client évolutif',
      ],
    },
    {
      id: 'professional-services',
      name: 'Services Professionnels',
      icon: Briefcase,
      painPoints: [
        'Intégration client chronophage',
        'Planification manuelle des réunions',
        'Communications client incohérentes',
      ],
      proposedStack: ['Assistant Vocal', 'Prospection Automatisée', 'Collecte de Prospects'],
      outcomes: [
        'Plus de temps pour le travail à haute valeur',
        'Relations client améliorées',
        'Processus d\'intégration rationalisé',
      ],
    },
  ];

  return (
    <div className="min-h-screen">
        <Header lang="fr" />
        <main className="container mx-auto px-4 py-16">
          <h1 className="text-5xl font-heading font-bold uppercase text-center mb-4 mt-8 scroll-reveal">
            Industries Que Nous <span className="text-primary">Servons</span>
          </h1>
          <p className="text-xl text-center text-muted-foreground mb-16 max-w-3xl mx-auto scroll-reveal">
            Solutions d'automatisation sur mesure pour les défis uniques de votre industrie.
          </p>
          <div className="space-y-16">
            {industries.map((industry, index) => {
              const Icon = industry.icon;
              return (
                <div
                  key={industry.name}
                  id={industry.id}
                  className="bg-background rounded-[20px] shadow-lg p-8 hover:shadow-primary/20 transition-shadow scroll-reveal scroll-mt-24"
                >
                  <div className="flex items-center gap-4 mb-6">
                    <div className="bg-primary/10 rounded-full p-4">
                      <Icon className="text-primary" size={32} strokeWidth={1.5} />
                    </div>
                    <h2 className="text-3xl font-heading font-bold uppercase">{industry.name}</h2>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {/* Pain Points */}
                    <div 
                      className="scroll-reveal"
                      style={{ animationDelay: '0ms' }}
                    >
                      <div className="flex items-center gap-2 mb-4">
                        <AlertCircle className="text-destructive" size={24} strokeWidth={1.5} />
                        <h3 className="text-lg font-semibold text-foreground">Points Douloureux</h3>
                      </div>
                      <ul className="space-y-2">
                        {industry.painPoints.map((point, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <span className="text-destructive mt-1">•</span>
                            <span className="text-muted-foreground">{point}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Proposed Stack */}
                    <div 
                      className="scroll-reveal"
                      style={{ animationDelay: '100ms' }}
                    >
                      <div className="flex items-center gap-2 mb-4">
                        <Wrench className="text-primary" size={24} strokeWidth={1.5} />
                        <h3 className="text-lg font-semibold text-foreground">Stack Proposé</h3>
                      </div>
                      <ul className="space-y-2">
                        {industry.proposedStack.map((service, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <span className="text-primary mt-1">•</span>
                            <span className="text-muted-foreground">{service}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Expected Outcomes */}
                    <div 
                      className="scroll-reveal"
                      style={{ animationDelay: '200ms' }}
                    >
                      <div className="flex items-center gap-2 mb-4">
                        <CheckCircle2 className="text-green-600" size={24} strokeWidth={1.5} />
                        <h3 className="text-lg font-semibold text-foreground">Résultats Attendus</h3>
                      </div>
                      <ul className="space-y-2">
                        {industry.outcomes.map((outcome, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <CheckCircle2 className="text-green-600 mt-1 flex-shrink-0" size={16} />
                            <span className="text-muted-foreground">{outcome}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </main>
        <Footer lang="fr" />
      </div>
  );
};

export default Industries;
