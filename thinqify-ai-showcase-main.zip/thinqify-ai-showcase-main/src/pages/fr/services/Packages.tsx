import { useEffect } from 'react';
import { Box } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';

import { useScrollReveal } from '@/hooks/useScrollReveal';

const Packages = () => {
  useScrollReveal();

  useEffect(() => {
    document.documentElement.lang = 'fr';
  }, []);

  return (
    <div className="min-h-screen">
        <Header lang="fr" />
        <main className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-4 mb-6 scroll-reveal">
              <Box size={48} className="text-primary" strokeWidth={1.5} />
              <h1 className="text-5xl font-heading font-bold uppercase">
                <span className="text-primary">Forfaits d'Automatisation</span> Combinés
              </h1>
            </div>
            
            <div className="space-y-8 text-lg text-muted-foreground leading-relaxed">
              <p className="scroll-reveal">
                Obtenez des bundles d'automatisation pré-configurés qui combinent plusieurs systèmes adaptés à votre
                industrie. Ces forfaits intègrent nos services de base dans des flux de travail cohésifs conçus pour
                résoudre efficacement les défis spécifiques à l'industrie.
              </p>

              <div className="scroll-reveal">
                <h2 className="text-2xl font-heading font-bold uppercase mb-4 text-foreground">
                  Cas d'Usage et Avantages
                </h2>
                <p className="mb-4">
                  Au lieu de mettre en œuvre des systèmes d'automatisation individuels séparément, les forfaits combinés
                  fournissent une automatisation de bout en bout pour des scénarios commerciaux courants. Par exemple, un forfait immobilier
                  pourrait inclure la collecte de prospects, la prospection automatisée, un assistant vocal pour les demandes de propriété
                  et l'automatisation des réseaux sociaux — tous travaillant ensemble de manière transparente.
                </p>
                <p>
                  Mise en œuvre plus rapide que les solutions personnalisées. Coût total inférieur aux systèmes individuels.
                  Flux de travail éprouvés testés sur plusieurs clients. Systèmes conçus pour fonctionner ensemble avec
                  des données partagées et des actions coordonnées pour une efficacité maximale.
                </p>
              </div>

              <div className="scroll-reveal">
                <h2 className="text-2xl font-heading font-bold uppercase mb-4 text-foreground">
                  Utilisateurs Cibles
                </h2>
                <p>
                  Idéal pour les entreprises souhaitant une automatisation complète sans la complexité d'une
                  intégration personnalisée. Disponible pour l'éducation, l'immobilier, la santé, le commerce électronique et
                  les services professionnels. Chaque forfait est personnalisable selon vos besoins spécifiques tout en
                  maintenant l'efficacité d'une solution pré-construite.
                </p>
              </div>
            </div>
          </div>
        </main>
        <Footer lang="fr" />
      </div>
  );
};

export default Packages;
