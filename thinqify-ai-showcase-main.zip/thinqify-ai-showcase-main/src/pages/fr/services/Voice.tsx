import { useEffect } from 'react';
import { Phone } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';

import { useScrollReveal } from '@/hooks/useScrollReveal';

const Voice = () => {
  useScrollReveal();

  useEffect(() => {
    document.documentElement.lang = 'fr';
  }, []);

  return (
    <div className="min-h-screen">
        <Header lang="fr" />
        <main className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-4 mb-6 scroll-reveal">
              <Phone size={48} className="text-primary" strokeWidth={1.5} />
              <h1 className="text-5xl font-heading font-bold uppercase">
                <span className="text-primary">Assistant Vocal</span> IA
              </h1>
            </div>
            
            <div className="space-y-8 text-lg text-muted-foreground leading-relaxed">
              <p className="scroll-reveal">
                Déployez un assistant vocal IA qui répond aux appels téléphoniques, gère la planification de rendez-vous
                et gère les demandes des clients par conversation naturelle. Le système s'intègre avec
                votre calendrier, CRM et outils professionnels pour fournir une automatisation vocale transparente.
              </p>

              <div className="scroll-reveal">
                <h2 className="text-2xl font-heading font-bold uppercase mb-4 text-foreground">
                  Cas d'Usage et Avantages
                </h2>
                <p className="mb-4">
                  Parfait pour les cabinets médicaux, les services professionnels, les salons et toute entreprise qui
                  gère les réservations de rendez-vous par téléphone. L'assistant IA répond aux appels 24h/24 et 7j/7, prend
                  des rendez-vous, envoie des confirmations, gère les reprogrammations et fournit des informations sur
                  vos services.
                </p>
                <p>
                  Ne manquez jamais un appel ou une opportunité de réservation. Réduisez les taux d'absence avec des
                  rappels automatisés. Libérez votre personnel des tâches téléphoniques pour se concentrer sur le service client en personne. Le
                  système sonne naturel, professionnel et représente parfaitement votre marque.
                </p>
              </div>

              <div className="scroll-reveal">
                <h2 className="text-2xl font-heading font-bold uppercase mb-4 text-foreground">
                  Utilisateurs Cibles
                </h2>
                <p>
                  Idéal pour les professionnels de santé, les cabinets dentaires, les salons de beauté, les cabinets juridiques,
                  les cabinets de conseil et les entreprises de services avec des opérations basées sur les rendez-vous. Fonctionne avec
                  Google Calendar, Outlook et les principaux systèmes de gestion de cabinet pour une planification
                  transparente.
                </p>
              </div>
            </div>
          </div>
        </main>
        <Footer lang="fr" />
      </div>
  );
};

export default Voice;
