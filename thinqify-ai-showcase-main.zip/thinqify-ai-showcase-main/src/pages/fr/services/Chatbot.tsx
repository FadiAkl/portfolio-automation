import { useEffect } from 'react';
import { MessageSquare } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';

import { useScrollReveal } from '@/hooks/useScrollReveal';

const Chatbot = () => {
  useScrollReveal();

  useEffect(() => {
    document.documentElement.lang = 'fr';
  }, []);

  return (
    <div className="min-h-screen">
        <Header lang="fr" />
        <main className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-4 mb-6 scroll-reveal">
              <MessageSquare size={48} className="text-primary" strokeWidth={1.5} />
              <h1 className="text-5xl font-heading font-bold uppercase">
                <span className="text-primary">Chatbot</span> IA
              </h1>
            </div>
            
            <div className="space-y-8 text-lg text-muted-foreground leading-relaxed">
              <p className="scroll-reveal">
                Déployez un chatbot intelligent qui répond aux questions des clients, gère les réservations et
                fournit un support 24h/24 sur votre site web, application mobile ou plateformes de messagerie. Notre IA
                comprend le contexte, apprend des interactions et escalade les problèmes complexes de manière appropriée.
              </p>

              <div className="scroll-reveal">
                <h2 className="text-2xl font-heading font-bold uppercase mb-4 text-foreground">
                  Cas d'Usage et Avantages
                </h2>
                <p className="mb-4">
                  Parfait pour les entreprises recevant des demandes de renseignements répétitives des clients, des demandes de réservation ou
                  des questions sur les produits. Le chatbot gère les FAQ, traite les rendez-vous, capture les prospects,
                  et fournit des réponses instantanées pendant que votre équipe se concentre sur les problèmes complexes.
                </p>
                <p>
                  Les temps de réponse passent d'heures à secondes. La satisfaction client s'améliore avec des
                  réponses instantanées et précises. Les coûts de support diminuent car l'IA gère les demandes de routine. Le
                  système suit toutes les interactions, fournissant des informations précieuses sur les besoins des clients.
                </p>
              </div>

              <div className="scroll-reveal">
                <h2 className="text-2xl font-heading font-bold uppercase mb-4 text-foreground">
                  Utilisateurs Cibles
                </h2>
                <p>
                  Idéal pour les entreprises de commerce électronique, les prestataires de services, les établissements de santé, les
                  institutions éducatives et toute organisation avec des opérations en contact avec les clients. S'intègre avec
                  votre site web, CRM, systèmes de réservation et bases de connaissances pour fournir des réponses contextuelles et
                  intelligentes.
                </p>
              </div>
            </div>
          </div>
        </main>
        <Footer lang="fr" />
      </div>
  );
};

export default Chatbot;
