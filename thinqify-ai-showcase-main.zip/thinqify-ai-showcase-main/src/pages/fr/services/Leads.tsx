import { useEffect } from 'react';
import { Database } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';

import { useScrollReveal } from '@/hooks/useScrollReveal';

const Leads = () => {
  useScrollReveal();

  useEffect(() => {
    document.documentElement.lang = 'fr';
  }, []);

  return (
    <div className="min-h-screen">
        <Header lang="fr" />
        <main className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-4 mb-6 scroll-reveal">
              <Database size={48} className="text-primary" strokeWidth={1.5} />
              <h1 className="text-5xl font-heading font-bold uppercase">
                <span className="text-primary">Collecte Automatisée</span> de Prospects
              </h1>
            </div>
            
            <div className="space-y-8 text-lg text-muted-foreground leading-relaxed">
              <p className="scroll-reveal">
                Construisez des bases de données de prospects complètes automatiquement avec une IA qui collecte, vérifie et
                enrichit les informations de contact professionnelles. Le système recueille des emails, noms, détails d'entreprise,
                industries et emplacements à partir de plusieurs sources, fournissant des listes de prospects qualifiés prêtes
                pour la prospection.
              </p>

              <div className="scroll-reveal">
                <h2 className="text-2xl font-heading font-bold uppercase mb-4 text-foreground">
                  Cas d'Usage et Avantages
                </h2>
                <p className="mb-4">
                  Parfait pour les équipes commerciales B2B, les agences de marketing et les professionnels du développement commercial
                  qui ont besoin de listes de prospects ciblées. Le système recherche dans les bases de données, les
                  plateformes sociales et les sources publiques pour trouver les décideurs correspondant à votre profil de client
                  idéal.
                </p>
                <p>
                  Arrêtez de rechercher manuellement les prospects. Obtenez des informations de contact vérifiées et à jour à
                  grande échelle. Concentrez-vous sur la vente plutôt que sur la recherche. L'IA garantit la qualité des données,
                  supprime les doublons et valide les informations de contact avant la livraison.
                </p>
              </div>

              <div className="scroll-reveal">
                <h2 className="text-2xl font-heading font-bold uppercase mb-4 text-foreground">
                  Utilisateurs Cibles
                </h2>
                <p>
                  Idéal pour les équipes commerciales, les agences de recrutement, les agences de marketing et toute organisation
                  qui dépend d'une génération de prospects cohérente. S'intègre avec votre CRM et vos outils de prospection
                  pour une automatisation de flux de travail transparente.
                </p>
              </div>
            </div>
          </div>
        </main>
        <Footer lang="fr" />
      </div>
  );
};

export default Leads;
