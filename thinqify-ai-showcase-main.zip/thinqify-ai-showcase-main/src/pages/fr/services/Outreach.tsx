import { useEffect } from 'react';
import { Send } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';

import { useScrollReveal } from '@/hooks/useScrollReveal';

const Outreach = () => {
  useScrollReveal();

  useEffect(() => {
    document.documentElement.lang = 'fr';
  }, []);

  return (
    <div className="min-h-screen">
        <Header lang="fr" />
        <main className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-4 mb-6 scroll-reveal">
              <Send size={48} className="text-primary" strokeWidth={1.5} />
              <h1 className="text-5xl font-heading font-bold uppercase">
                Système de <span className="text-primary">Prospection Automatisée</span>
              </h1>
            </div>
            
            <div className="space-y-8 text-lg text-muted-foreground leading-relaxed">
              <p className="scroll-reveal">
                Transformez vos opérations de prospection avec une automatisation intelligente qui envoie des messages personnalisés
                aux prospects automatiquement. Notre système se connecte à vos feuilles de données, CRM ou
                bases de données et exécute des campagnes de prospection ciblées à grande échelle.
              </p>

              <div className="scroll-reveal">
                <h2 className="text-2xl font-heading font-bold uppercase mb-4 text-foreground">
                  Cas d'Usage et Avantages
                </h2>
                <p className="mb-4">
                  Parfait pour les équipes commerciales, les recruteurs et les professionnels du marketing qui doivent atteindre
                  des centaines ou des milliers de prospects avec des messages personnalisés. Le système maintient
                  des modèles d'envoi semblables à l'humain, respecte les préférences de communication et suit l'engagement
                  automatiquement.
                </p>
                <p>
                  Votre équipe économise des heures par jour sur la prospection manuelle tout en maintenant la personnalisation.
                  Les taux de réponse s'améliorent car les messages sont opportuns, pertinents et correctement séquencés.
                  Le système apprend des modèles d'engagement pour optimiser les campagnes futures.
                </p>
              </div>

              <div className="scroll-reveal">
                <h2 className="text-2xl font-heading font-bold uppercase mb-4 text-foreground">
                  Utilisateurs Cibles
                </h2>
                <p>
                  Idéal pour les entreprises B2B, les agences de recrutement, les professionnels de l'immobilier et toute
                  organisation qui dépend d'une prospection cohérente et personnalisée. Fonctionne sur email,
                  SMS, LinkedIn et autres canaux de communication. S'intègre parfaitement avec vos
                  outils et flux de travail existants.
                </p>
              </div>
            </div>
          </div>
        </main>
        <Footer lang="fr" />
      </div>
  );
};

export default Outreach;
