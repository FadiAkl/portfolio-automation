import { useEffect } from 'react';
import { Users } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';

import { useScrollReveal } from '@/hooks/useScrollReveal';

const Social = () => {
  useScrollReveal();

  useEffect(() => {
    document.documentElement.lang = 'fr';
  }, []);

  return (
    <div className="min-h-screen">
        <Header lang="fr" />
        <main className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-4 mb-6 scroll-reveal">
              <Users size={48} className="text-primary" strokeWidth={1.5} />
              <h1 className="text-5xl font-heading font-bold uppercase">
                <span className="text-primary">Automatisation</span> des Réseaux Sociaux
              </h1>
            </div>
            
            <div className="space-y-8 text-lg text-muted-foreground leading-relaxed">
              <p className="scroll-reveal">
                Automatisez votre engagement sur les réseaux sociaux avec une IA qui répond aux messages directs, commentaires,
                et identifie les prospects potentiels sur Instagram, Facebook, LinkedIn et autres plateformes.
                Le système maintient la voix de votre marque tout en développant votre présence sociale.
              </p>

              <div className="scroll-reveal">
                <h2 className="text-2xl font-heading font-bold uppercase mb-4 text-foreground">
                  Cas d'Usage et Avantages
                </h2>
                <p className="mb-4">
                  Parfait pour les entreprises avec une présence active sur les réseaux sociaux recevant des volumes élevés de
                  messages et commentaires. L'IA répond instantanément aux questions courantes, identifie les
                  opportunités de vente, escalade les problèmes complexes et maintient l'engagement même en dehors des heures de
                  bureau.
                </p>
                <p>
                  Ne manquez jamais un prospect ou une demande client. Répondez à tous les messages et commentaires rapidement.
                  Améliorez les métriques d'engagement sur les réseaux sociaux. Libérez votre équipe de réseaux sociaux pour se concentrer sur
                  la création de contenu et la stratégie plutôt que sur les réponses de routine.
                </p>
              </div>

              <div className="scroll-reveal">
                <h2 className="text-2xl font-heading font-bold uppercase mb-4 text-foreground">
                  Utilisateurs Cibles
                </h2>
                <p>
                  Idéal pour les marques de commerce électronique, les influenceurs, les agences et les entreprises utilisant les réseaux sociaux
                  comme point de contact client principal. Fonctionne sur toutes les principales plateformes et s'intègre avec
                  votre CRM pour suivre les prospects et les conversations de manière systématique.
                </p>
              </div>
            </div>
          </div>
        </main>
        <Footer lang="fr" />
      </div>
  );
};

export default Social;
