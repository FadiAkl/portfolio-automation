import { useEffect } from 'react';
import { MessageSquare, Phone, Send, Users, Database, Box, List, Brain, CheckCircle, Calendar, Target, Package } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import ServiceCard from '@/components/ui/service-card';
import ProcessFlow from '@/components/ui/process-flow';

import { useScrollReveal } from '@/hooks/useScrollReveal';

const Services = () => {
  useScrollReveal();

  useEffect(() => {
    document.documentElement.lang = 'fr';
  }, []);

  const services = [
    {
      title: 'Système de Prospection Automatisée',
      description: 'Envoie des messages personnalisés automatiquement depuis vos données vers vos prospects.',
      icon: Send,
      href: '/fr/services/outreach',
    },
    {
      title: 'Chatbot IA',
      description: 'Répond aux questions des clients, gère les réservations et offre un support 24h/24.',
      icon: MessageSquare,
      href: '/fr/services/chatbot',
    },
    {
      title: 'Assistant Vocal IA',
      description: 'Répond aux appels téléphoniques, réserve ou annule des rendez-vous via intégrations calendrier.',
      icon: Phone,
      href: '/fr/services/voice',
    },
    {
      title: 'Automatisation des Réseaux Sociaux',
      description: 'Répond aux DM/commentaires, identifie les prospects, gère les interactions.',
      icon: Users,
      href: '/fr/services/social',
    },
    {
      title: 'Collecte Automatisée de Prospects',
      description: 'Collecte des données d\'entreprise vérifiées (emails, noms, secteurs, emplacements).',
      icon: Database,
      href: '/fr/services/leads',
    },
    {
      title: 'Forfaits d\'Automatisation Combinés',
      description: 'Bundles pré-construits combinant plusieurs systèmes par industrie.',
      icon: Box,
      href: '/fr/services/packages',
    },
  ];

  return (
    <div className="min-h-screen">
        <Header lang="fr" />
        <main className="container mx-auto px-4 py-16">
          <h1 className="text-5xl font-heading font-bold uppercase text-center mb-4 scroll-reveal">
            Nos <span className="text-primary">Services</span>
          </h1>
          <p className="text-xl text-center text-muted-foreground mb-16 max-w-3xl mx-auto scroll-reveal">
            Systèmes d'automatisation intelligents conçus pour développer vos opérations et réduire le travail manuel.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service) => (
              <ServiceCard key={service.href} {...service} />
            ))}
          </div>

          {/* Process Flows */}
          <div className="mt-20 space-y-16">
            <div>
              <h3 className="text-2xl font-heading font-bold uppercase text-center mb-8 scroll-reveal">
                Processus de <span className="text-primary">Prospection</span>
              </h3>
              <ProcessFlow
                steps={[
                  { icon: List, label: 'Données' },
                  { icon: Brain, label: 'IA Personnalisation' },
                  { icon: Send, label: 'Prospection Ciblée' },
                ]}
              />
            </div>

            <div>
              <h3 className="text-2xl font-heading font-bold uppercase text-center mb-8 scroll-reveal">
                Flux de <span className="text-primary">Chatbot IA</span>
              </h3>
              <ProcessFlow
                steps={[
                  { icon: MessageSquare, label: 'Question Client' },
                  { icon: Brain, label: 'Compréhension IA' },
                  { icon: CheckCircle, label: 'Réponse Instantanée' },
                ]}
              />
            </div>

            <div>
              <h3 className="text-2xl font-heading font-bold uppercase text-center mb-8 scroll-reveal">
                Flux <span className="text-primary">Assistant Vocal</span>
              </h3>
              <ProcessFlow
                steps={[
                  { icon: Phone, label: 'Appel Entrant' },
                  { icon: Calendar, label: 'Planification IA' },
                  { icon: CheckCircle, label: 'Confirmation Calendrier' },
                ]}
              />
            </div>

            <div>
              <h3 className="text-2xl font-heading font-bold uppercase text-center mb-8 scroll-reveal">
                Pipeline de <span className="text-primary">Collecte</span>
              </h3>
              <ProcessFlow
                steps={[
                  { icon: Database, label: 'Listes de Prospects' },
                  { icon: Brain, label: 'IA Personnalisation' },
                  { icon: Target, label: 'Prospection Ciblée' },
                ]}
              />
            </div>

            <div>
              <h3 className="text-2xl font-heading font-bold uppercase text-center mb-8 scroll-reveal">
                Intégration <span className="text-primary">Forfaits</span>
              </h3>
              <ProcessFlow
                steps={[
                  { icon: Package, label: 'Systèmes Multiples' },
                  { icon: Brain, label: 'Moteur IA Unifié' },
                  { icon: Target, label: 'Automatisation Complète' },
                ]}
              />
            </div>
          </div>
        </main>
        <Footer lang="fr" />
      </div>
  );
};

export default Services;
