import { useEffect } from 'react';
import { Users, Target, MessageSquare, Shield, Inbox, BarChart3, MessageCircle, Filter, Flag } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';

import { useScrollReveal } from '@/hooks/useScrollReveal';

const Social = () => {
  useScrollReveal();

  useEffect(() => {
    document.documentElement.lang = 'en';
  }, []);

  const features = [
    { icon: Target, text: "Keyword/intent detection on DM/comment" },
    { icon: MessageSquare, text: "Smart replies with links and CTAs" },
    { icon: Users, text: "Lead capture and qualification" },
    { icon: Shield, text: "Spam filtering and tone control" },
    { icon: Inbox, text: "Team inbox handoff" },
    { icon: BarChart3, text: "Performance and A/B on replies" }
  ];

  return (
    <div className="min-h-screen bg-white">
        <Header lang="en" />
        <main className="container mx-auto px-4 py-24 max-w-[1200px]">
          {/* Hero Section */}
          <div className="text-center mb-16 scroll-reveal">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-[#00CED1]/10 mb-6">
              <Users className="w-8 h-8 text-[#00CED1]" strokeWidth={1.5} />
            </div>
            <h1 className="text-5xl font-heading font-bold text-black mb-4">
              Social Media Automation
            </h1>
            <p className="text-xl text-black/70 mb-2">
              Auto-reply DMs/comments and route hot leads.
            </p>
            <p className="text-base text-black/60">
              Detects intent, sends the right link, escalates when needed.
            </p>
          </div>

          {/* Who Uses This */}
          <div className="mb-16 scroll-reveal">
            <div className="bg-white rounded-2xl border border-black/10 shadow-sm p-8">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 rounded-lg bg-[#00CED1]/10 flex items-center justify-center">
                  <Users className="w-4 h-4 text-[#00CED1]" />
                </div>
                <h2 className="text-lg font-heading font-semibold text-black">Who uses this</h2>
              </div>
              <p className="text-black/70">
                Influencers, coaches, fitness, e-commerce, restaurants.
              </p>
            </div>
          </div>

          {/* What You Get */}
          <div className="mb-16 scroll-reveal">
            <h2 className="text-3xl font-heading font-bold text-black text-center mb-12">
              What you get
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <div 
                  key={index}
                  className="flex items-start gap-4 p-6 bg-white rounded-xl border border-black/10 shadow-sm scroll-reveal"
                  style={{ animationDelay: `${index * 80}ms` }}
                >
                  <div className="w-10 h-10 rounded-lg bg-[#00CED1]/10 flex items-center justify-center flex-shrink-0">
                    <feature.icon className="w-5 h-5 text-[#00CED1]" />
                  </div>
                  <p className="text-black/80 pt-2">{feature.text}</p>
                </div>
              ))}
            </div>
          </div>

          {/* How It Fits */}
          <div className="scroll-reveal">
            <h2 className="text-3xl font-heading font-bold text-black text-center mb-12">
              How it fits
            </h2>
            <div className="bg-[#00CED1]/5 rounded-2xl p-8 md:p-12">
              <div className="flex flex-col md:flex-row items-center justify-center gap-6 md:gap-8">
                <div className="bg-white rounded-full px-6 py-3 border border-[#00CED1]/20 shadow-sm flex items-center gap-3">
                  <MessageCircle className="w-7 h-7 text-[#00CED1] flex-shrink-0" />
                  <p className="text-black/80 font-medium">DM/Comment</p>
                </div>
                <div className="hidden md:block w-12 h-0.5 bg-[#00CED1]/30"></div>
                <div className="md:hidden h-8 w-0.5 bg-[#00CED1]/30"></div>
                <div className="bg-[#00CED1] rounded-full px-8 py-4 shadow-lg flex items-center gap-3">
                  <Filter className="w-7 h-7 text-white flex-shrink-0" />
                  <p className="text-white font-semibold">Intent Classifier</p>
                </div>
                <div className="hidden md:block w-12 h-0.5 bg-[#00CED1]/30"></div>
                <div className="md:hidden h-8 w-0.5 bg-[#00CED1]/30"></div>
                <div className="bg-white rounded-full px-6 py-3 border border-[#00CED1]/20 shadow-sm flex items-center gap-3">
                  <Flag className="w-7 h-7 text-[#00CED1] flex-shrink-0" />
                  <p className="text-black/80 font-medium">Auto-Reply + Lead Routing</p>
                </div>
              </div>
            </div>
          </div>
        </main>
        <Footer lang="en" />
      </div>
  );
};

export default Social;
