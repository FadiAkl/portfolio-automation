import { useEffect } from 'react';
import { Package, Building2, Heart, ShoppingCart, Briefcase, Zap } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';

import { useScrollReveal } from '@/hooks/useScrollReveal';

const Packages = () => {
  useScrollReveal();

  useEffect(() => {
    document.documentElement.lang = 'en';
  }, []);

  const bundles = [
    {
      icon: Building2,
      title: "Real Estate Bundle",
      includes: [
        "Lead collection",
        "Outreach system",
        "AI chatbot",
        "Voice assistant"
      ],
      outcome: "More qualified viewings from first contact."
    },
    {
      icon: Heart,
      title: "Healthcare Bundle",
      includes: [
        "AI chatbot",
        "Voice assistant",
        "Booking system",
        "Patient CRM integration"
      ],
      outcome: "Reduced wait times and fewer missed appointments."
    },
    {
      icon: ShoppingCart,
      title: "E-commerce Bundle",
      includes: [
        "AI chatbot",
        "Social automation",
        "Outreach campaigns"
      ],
      outcome: "Higher conversion rates from product guidance."
    },
    {
      icon: Briefcase,
      title: "Agency Bundle",
      includes: [
        "Lead scraper",
        "Outreach system",
        "Social automation"
      ],
      outcome: "Full sales funnel from discovery to booking."
    }
  ];

  return (
    <div className="min-h-screen bg-white">
        <Header lang="en" />
        <main className="container mx-auto px-4 py-24 max-w-[1200px]">
          {/* Hero Section */}
          <div className="text-center mb-24 scroll-reveal">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-[#00CED1]/10 mb-6">
              <Package className="w-8 h-8 text-[#00CED1]" strokeWidth={1.5} />
            </div>
            <h1 className="text-5xl font-heading font-bold text-black mb-4">
              Integrated AI Bundles
            </h1>
            <p className="text-xl text-black/70 mb-2">
              Industry-ready stacks that just work.
            </p>
            <p className="text-base text-black/60">
              Combined systems tuned to your industry.
            </p>
          </div>

          {/* Bundles Grid */}
          <div className="grid md:grid-cols-2 gap-8">
            {bundles.map((bundle, index) => (
              <div 
                key={index}
                className="bg-white rounded-2xl border border-black/10 shadow-sm p-8 card-hover-effect scroll-reveal"
                style={{ animationDelay: `${index * 80}ms` }}
              >
                {/* Icon and Title */}
                <div className="flex items-start gap-4 mb-6">
                  <div className="w-12 h-12 rounded-xl bg-[#00CED1]/10 flex items-center justify-center flex-shrink-0">
                    <bundle.icon className="w-6 h-6 text-[#00CED1]" strokeWidth={1.5} />
                  </div>
                  <h3 className="text-2xl font-heading font-bold text-black pt-2">
                    {bundle.title}
                  </h3>
                </div>

                {/* Includes Section */}
                <div className="mb-6 pb-6 border-b border-black/5">
                  <p className="text-xs font-semibold text-black/40 uppercase tracking-wider mb-3">
                    Includes
                  </p>
                  <div className="space-y-2">
                    {bundle.includes.map((item, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <Zap className="w-4 h-4 text-[#00CED1] flex-shrink-0" />
                        <span className="text-black/70">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Expected Outcome */}
                <div>
                  <p className="text-xs font-semibold text-black/40 uppercase tracking-wider mb-2">
                    Expected Outcome
                  </p>
                  <p className="text-[#22C55E] font-medium">
                    {bundle.outcome}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </main>
        <Footer lang="en" />
      </div>
  );
};

export default Packages;
