import { useEffect } from 'react';
import { GraduationCap, Home as HomeIcon, Heart, ShoppingBag, Briefcase, AlertCircle, CheckCircle2, Wrench } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';

import { useScrollReveal } from '@/hooks/useScrollReveal';

const Industries = () => {
  useScrollReveal();

  useEffect(() => {
    document.documentElement.lang = 'en';
  }, []);

  const industries = [
    {
      id: 'education',
      name: 'Education',
      icon: GraduationCap,
      painPoints: [
        'High volume of repetitive student inquiries',
        'Manual enrollment and registration processes',
        'Limited support hours for parents and students',
      ],
      proposedStack: ['AI Chatbot', 'Automated Outreach', 'Voice Assistant'],
      outcomes: [
        'Reduced administrative workload by 60%',
        'Improved student engagement and satisfaction',
        '24/7 support availability',
      ],
    },
    {
      id: 'real-estate',
      name: 'Real Estate',
      icon: HomeIcon,
      painPoints: [
        'Time-consuming lead qualification',
        'Scheduling conflicts for property viewings',
        'Inefficient client follow-up',
      ],
      proposedStack: ['Lead Collection', 'Automated Outreach', 'Social Media Automation'],
      outcomes: [
        'More qualified leads in pipeline',
        'Efficient property viewing scheduling',
        'Consistent client communication',
      ],
    },
    {
      id: 'healthcare',
      name: 'Healthcare & Clinics',
      icon: Heart,
      painPoints: [
        'High no-show rates for appointments',
        'Overwhelming phone call volume',
        'Manual appointment booking and reminders',
      ],
      proposedStack: ['AI Voice Assistant', 'AI Chatbot', 'Automated Outreach'],
      outcomes: [
        'Reduced no-show rates by 40%',
        'Better patient experience',
        'HIPAA-compliant automated communications',
      ],
    },
    {
      id: 'ecommerce',
      name: 'E-Commerce',
      icon: ShoppingBag,
      painPoints: [
        'High customer support ticket volume',
        'Delayed responses to order inquiries',
        'Limited social media engagement capacity',
      ],
      proposedStack: ['AI Chatbot', 'Social Media Automation', 'Automated Outreach'],
      outcomes: [
        'Increased customer satisfaction scores',
        'Higher sales conversion rates',
        'Scalable customer support',
      ],
    },
    {
      id: 'professional-services',
      name: 'Professional Services',
      icon: Briefcase,
      painPoints: [
        'Time-consuming client onboarding',
        'Manual meeting scheduling back-and-forth',
        'Inconsistent client communications',
      ],
      proposedStack: ['Voice Assistant', 'Automated Outreach', 'Lead Collection'],
      outcomes: [
        'More time for high-value work',
        'Improved client relationships',
        'Streamlined onboarding process',
      ],
    },
  ];

  return (
    <div className="min-h-screen">
        <Header lang="en" />
        <main className="container mx-auto px-4 py-16">
          <h1 className="text-5xl font-heading font-bold uppercase text-center mb-4 mt-8 scroll-reveal">
            Industries We <span className="text-primary">Serve</span>
          </h1>
          <p className="text-xl text-center text-muted-foreground mb-16 max-w-3xl mx-auto scroll-reveal">
            Tailored automation solutions for your industry's unique challenges.
          </p>
          <div className="space-y-16">
            {industries.map((industry, index) => {
              const Icon = industry.icon;
              return (
                <div
                  key={industry.name}
                  id={industry.id}
                  className="bg-background rounded-[20px] shadow-lg p-8 hover:shadow-primary/20 transition-shadow scroll-reveal scroll-mt-24"
                >
                  <div className="flex items-center gap-4 mb-6">
                    <div className="bg-primary/10 rounded-full p-4">
                      <Icon className="text-primary" size={32} strokeWidth={1.5} />
                    </div>
                    <h2 className="text-3xl font-heading font-bold uppercase">{industry.name}</h2>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {/* Pain Points */}
                    <div 
                      className="scroll-reveal"
                      style={{ animationDelay: '0ms' }}
                    >
                      <div className="flex items-center gap-2 mb-4">
                        <AlertCircle className="text-destructive" size={24} strokeWidth={1.5} />
                        <h3 className="text-lg font-semibold text-foreground">Pain Points</h3>
                      </div>
                      <ul className="space-y-2">
                        {industry.painPoints.map((point, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <span className="text-destructive mt-1">•</span>
                            <span className="text-muted-foreground">{point}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Proposed Stack */}
                    <div 
                      className="scroll-reveal"
                      style={{ animationDelay: '100ms' }}
                    >
                      <div className="flex items-center gap-2 mb-4">
                        <Wrench className="text-primary" size={24} strokeWidth={1.5} />
                        <h3 className="text-lg font-semibold text-foreground">Proposed Stack</h3>
                      </div>
                      <ul className="space-y-2">
                        {industry.proposedStack.map((service, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <span className="text-primary mt-1">•</span>
                            <span className="text-muted-foreground">{service}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Expected Outcomes */}
                    <div 
                      className="scroll-reveal"
                      style={{ animationDelay: '200ms' }}
                    >
                      <div className="flex items-center gap-2 mb-4">
                        <CheckCircle2 className="text-green-600" size={24} strokeWidth={1.5} />
                        <h3 className="text-lg font-semibold text-foreground">Expected Outcomes</h3>
                      </div>
                      <ul className="space-y-2">
                        {industry.outcomes.map((outcome, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <CheckCircle2 className="text-green-600 mt-1 flex-shrink-0" size={16} />
                            <span className="text-muted-foreground">{outcome}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </main>
        <Footer lang="en" />
      </div>
  );
};

export default Industries;
