import { useEffect } from 'react';
import { MessageSquare, Phone, Send, Users, Database, Box, List, Brain, CheckCircle, Calendar, Target, Package } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import ServiceCard from '@/components/ui/service-card';
import ProcessFlow from '@/components/ui/process-flow';

import { useScrollReveal } from '@/hooks/useScrollReveal';

const Services = () => {
  useScrollReveal();

  useEffect(() => {
    document.documentElement.lang = 'en';
  }, []);

  const services = [
    {
      title: 'Automated Outreach System',
      description: 'Sends personalized messages automatically from data sheets to prospects.',
      icon: Send,
      href: '/en/services/outreach',
    },
    {
      title: 'AI Chatbot',
      description: 'Answers customer questions, handles bookings, and supports users 24/7.',
      icon: MessageSquare,
      href: '/en/services/chatbot',
    },
    {
      title: 'AI Voice Assistant',
      description: 'Answers phone calls, books or cancels appointments via calendar integrations.',
      icon: Phone,
      href: '/en/services/voice',
    },
    {
      title: 'Social Media Automation',
      description: 'Responds to DMs/comments, identifies leads, manages interactions.',
      icon: Users,
      href: '/en/services/social',
    },
    {
      title: 'Automated Lead Collection',
      description: 'Collects verified business data (emails, names, sectors, locations).',
      icon: Database,
      href: '/en/services/leads',
    },
    {
      title: 'Integrated AI Bundles',
      description: 'Pre-built bundles combining multiple systems per industry.',
      icon: Box,
      href: '/en/services/packages',
    },
  ];

  return (
    <div className="min-h-screen">
        <Header lang="en" />
        <main className="container mx-auto px-4 pt-24 pb-16">
          <h1 className="text-5xl font-heading font-bold uppercase text-center mb-4 scroll-reveal">
            Our <span className="text-primary">Services</span>
          </h1>
          <p className="text-xl text-center text-muted-foreground mb-16 max-w-3xl mx-auto scroll-reveal">
            Intelligent automation systems designed to scale your operations and reduce manual work.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service) => (
              <ServiceCard key={service.href} {...service} />
            ))}
          </div>

          {/* Process Flows */}
          <div className="mt-20 space-y-16">
            <div>
              <h3 className="text-2xl font-heading font-bold uppercase text-center mb-8 scroll-reveal">
                Automated Outreach <span className="text-primary">Process</span>
              </h3>
              <ProcessFlow
                steps={[
                  { icon: List, label: 'Data Sheets' },
                  { icon: Brain, label: 'AI Personalization' },
                  { icon: Send, label: 'Targeted Outreach' },
                ]}
              />
            </div>

            <div>
              <h3 className="text-2xl font-heading font-bold uppercase text-center mb-8 scroll-reveal">
                AI Chatbot <span className="text-primary">Workflow</span>
              </h3>
              <ProcessFlow
                steps={[
                  { icon: MessageSquare, label: 'Customer Query' },
                  { icon: Brain, label: 'AI Understanding' },
                  { icon: CheckCircle, label: 'Instant Answer' },
                ]}
              />
            </div>

            <div>
              <h3 className="text-2xl font-heading font-bold uppercase text-center mb-8 scroll-reveal">
                Voice Assistant <span className="text-primary">Flow</span>
              </h3>
              <ProcessFlow
                steps={[
                  { icon: Phone, label: 'Incoming Call' },
                  { icon: Calendar, label: 'AI Scheduling' },
                  { icon: CheckCircle, label: 'Calendar Confirmation' },
                ]}
              />
            </div>

            <div>
              <h3 className="text-2xl font-heading font-bold uppercase text-center mb-8 scroll-reveal">
                Lead Collection <span className="text-primary">Pipeline</span>
              </h3>
              <ProcessFlow
                steps={[
                  { icon: Database, label: 'Lead Lists' },
                  { icon: Brain, label: 'AI Personalization' },
                  { icon: Target, label: 'Targeted Outreach' },
                ]}
              />
            </div>

            <div>
              <h3 className="text-2xl font-heading font-bold uppercase text-center mb-8 scroll-reveal">
                Integrated AI <span className="text-primary">Bundles</span>
              </h3>
              <ProcessFlow
                steps={[
                  { icon: Package, label: 'Multiple Systems' },
                  { icon: Brain, label: 'Unified AI Engine' },
                  { icon: Target, label: 'Complete Automation' },
                ]}
              />
            </div>
          </div>
        </main>
        <Footer lang="en" />
      </div>
  );
};

export default Services;
