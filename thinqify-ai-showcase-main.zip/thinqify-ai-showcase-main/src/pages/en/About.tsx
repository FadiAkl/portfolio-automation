import { useEffect } from 'react';
import { Shield, Zap, Eye, Target, Mail } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';

import HeroGradient from '@/components/effects/HeroGradient';
import { useScrollReveal } from '@/hooks/useScrollReveal';
import { Button } from '@/components/ui/button';

const About = () => {
  useScrollReveal();

  useEffect(() => {
    document.documentElement.lang = 'en';
  }, []);

  const coreValues = [
    {
      icon: Shield,
      title: 'Privacy',
      description: 'We protect data and design for compliance by default.',
    },
    {
      icon: Zap,
      title: 'Performance',
      description: 'Fast, scalable systems with measurable uptime and latency.',
    },
    {
      icon: Eye,
      title: 'Clarity',
      description: 'Simple automation flows that make sense — no black boxes.',
    },
  ];

  const scrollToValues = () => {
    document.getElementById('values')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-white">
        <Header lang="en" />
        
        {/* Hero Section */}
        <section className="relative min-h-[70vh] flex items-center justify-center overflow-hidden">
          <HeroGradient />
          <div className="relative z-10 container mx-auto px-4 text-center">
            <h1 className="text-5xl md:text-6xl font-heading font-bold text-black mb-6 scroll-reveal">
              Empowering Businesses Through<br />
              <span className="text-[#00CED1]">Intelligent Automation</span>
            </h1>
            <p className="text-xl text-black/70 mb-8 max-w-2xl mx-auto scroll-reveal">
              At Thinqify, we design AI systems that save time, scale growth, and simplify operations.
            </p>
            <Button
              onClick={scrollToValues}
              className="bg-[#00CED1] hover:bg-[#00CED1]/90 text-white px-8 py-6 text-lg rounded-xl transition-all duration-300 hover:shadow-[0_0_20px_rgba(0,206,209,0.4)] hover:-translate-y-1 scroll-reveal"
            >
              Learn More
            </Button>
          </div>
        </section>

        <main className="container mx-auto px-4 py-24 max-w-[1200px]">
          {/* Core Values Section */}
          <section id="values" className="mb-24">
            <h2 className="text-3xl font-heading font-bold text-black text-center mb-12 scroll-reveal">
              Core Values
            </h2>
            <div className="grid md:grid-cols-3 gap-8">
              {coreValues.map((value, index) => (
                <div
                  key={index}
                  className="bg-white rounded-2xl border border-black/10 shadow-sm p-8 card-hover-effect scroll-reveal text-center"
                  style={{ animationDelay: `${index * 80}ms` }}
                >
                  <div className="flex justify-center mb-6">
                    <div className="w-16 h-16 rounded-xl bg-[#00CED1]/10 flex items-center justify-center">
                      <value.icon className="w-8 h-8 text-[#00CED1]" strokeWidth={1.5} />
                    </div>
                  </div>
                  <h3 className="text-xl font-heading font-bold text-black mb-3 hover-text">
                    {value.title}
                  </h3>
                  <p className="text-black/70">
                    {value.description}
                  </p>
                </div>
              ))}
            </div>
          </section>

          {/* CTA Section */}
          <section className="text-center scroll-reveal">
            <div className="bg-[#00CED1]/5 rounded-3xl p-12 md:p-16">
              <Target className="w-16 h-16 text-[#00CED1] mx-auto mb-6" strokeWidth={1.5} />
              <h2 className="text-3xl font-heading font-bold text-black mb-4">
                Ready to see what automation can do for you?
              </h2>
              <p className="text-xl text-black/70 mb-8 max-w-2xl mx-auto">
                Explore our services or get in touch to discuss your automation needs.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  onClick={() => window.location.href = '/en/services'}
                  className="bg-[#00CED1] hover:bg-[#00CED1]/90 text-white px-8 py-6 text-lg rounded-xl transition-all duration-300 hover:shadow-[0_0_20px_rgba(0,206,209,0.4)] hover:-translate-y-1"
                >
                  Explore Services
                </Button>
                <Button
                  onClick={() => window.location.href = 'mailto:fadi@thinqify.com'}
                  variant="outline"
                  className="border-2 border-[#00CED1] text-[#00CED1] hover:bg-[#00CED1] hover:text-white px-8 py-6 text-lg rounded-xl transition-all duration-300 hover:-translate-y-1"
                >
                  <Mail className="w-5 h-5 mr-2" />
                  Get in Touch
                </Button>
              </div>
            </div>
          </section>
        </main>
        
        <Footer lang="en" />
      </div>
  );
};

export default About;
