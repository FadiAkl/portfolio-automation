import { useEffect } from 'react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';

import { useScrollReveal } from '@/hooks/useScrollReveal';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const FAQ = () => {
  useScrollReveal();

  useEffect(() => {
    document.documentElement.lang = 'en';
  }, []);

  const faqs = [
    {
      question: 'What languages do you support?',
      answer:
        "All languages. Thinqify's AI systems communicate in any language configured by the client. We can set up multilingual support for your specific needs.",
    },
    {
      question: 'How does Thinqify handle data privacy?',
      answer:
        'We follow GDPR and international standards. Data stays encrypted and client-isolated. We never share your data with third parties, and you maintain full control over your information.',
    },
    {
      question: 'What tools or platforms can your systems integrate with?',
      answer:
        'CRMs (Salesforce, HubSpot), websites, calendars (Google Calendar, Outlook), chat platforms (WhatsApp, Messenger), and social channels (Instagram, Facebook). We can also build custom integrations for your specific tools.',
    },
    {
      question: 'Do I need technical skills to use Thinqify?',
      answer:
        'No. Solutions are turnkey and managed, requiring no coding. We handle all technical aspects, and provide a simple interface for managing your automation systems.',
    },
    {
      question: 'How are updates or issues handled?',
      answer:
        'Depending on your maintenance plan, Thinqify provides bug fixes, improvements, or full hosting. We monitor systems 24/7 and proactively address issues before they impact your operations.',
    },
    {
      question: 'Which industries can benefit most?',
      answer:
        'Education, Real Estate, Healthcare, E-commerce, Professional Services, and more. Any business with repetitive communication, scheduling, or data collection tasks can benefit from automation.',
    },
    {
      question: 'How do I get started?',
      answer:
        'Contact us at Fadi@thinqify.com for a consultation. We analyze your needs, propose a scope and timeline, and deploy the system. Most implementations are complete within 2-4 weeks.',
    },
  ];

  return (
    <div className="min-h-screen">
        <Header lang="en" />
        <main className="container mx-auto px-4 py-16">
          <h1 className="text-5xl font-heading font-bold uppercase text-center mb-4 mt-8 scroll-reveal">
            Frequently Asked <span className="text-primary">Questions</span>
          </h1>
          <div className="max-w-3xl mx-auto mt-12">
            <Accordion type="single" collapsible className="space-y-4">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`} className="scroll-reveal">
                  <AccordionTrigger className="text-left font-heading font-semibold text-lg">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </main>
        <Footer lang="en" />
      </div>
  );
};

export default FAQ;
