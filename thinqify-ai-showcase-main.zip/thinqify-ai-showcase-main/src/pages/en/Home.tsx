import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, Phone, Mail, Share2, Database, Package, GraduationCap, Building2, Heart, ShoppingCart, Briefcase, Shield, Gauge, Eye } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import ServiceCard from '@/components/ui/service-card';

import HeroGradient from '@/components/effects/HeroGradient';
import { useScrollReveal } from '@/hooks/useScrollReveal';
import { Button } from '@/components/ui/button';

const Home = () => {
  useScrollReveal();

  useEffect(() => {
    document.documentElement.lang = 'en';
  }, []);

  const services = [
    {
      title: 'Automated Outreach System',
      icon: Mail,
      shortDescription: 'Personalized at scale from your lead lists.',
      href: '/en/services/outreach',
    },
    {
      title: 'AI Chatbot',
      icon: MessageSquare,
      shortDescription: '24/7 answers, bookings, and guided sales.',
      href: '/en/services/chatbot',
    },
    {
      title: 'AI Voice Assistant',
      icon: Phone,
      shortDescription: 'Picks up every call. Schedules instantly.',
      href: '/en/services/voice',
    },
    {
      title: 'Social Media Automation',
      icon: Share2,
      shortDescription: 'Auto-reply to DMs and route hot leads.',
      href: '/en/services/social',
    },
    {
      title: 'Automated Lead Collection',
      icon: Database,
      shortDescription: 'Targeted lists with roles, emails, phones.',
      href: '/en/services/leads',
    },
    {
      title: 'Integrated AI Bundles',
      icon: Package,
      shortDescription: 'Industry-ready stacks that just work.',
      href: '/en/services/packages',
    },
  ];

  return (
    <div className="min-h-screen">
        <Header lang="en" />
        <main className="pt-16">
          {/* Hero Section */}
          <section className="relative container mx-auto px-4 overflow-hidden" style={{ paddingTop: '20vh', paddingBottom: '10vh' }}>
            <HeroGradient />
            <div className="relative z-10 text-center" style={{ paddingTop: '10vh', paddingBottom: '10vh' }}>
              <h1 className="text-5xl md:text-7xl font-heading font-bold uppercase mb-6 scroll-reveal" style={{ animationDelay: '500ms' }}>
                AI, integrated.
                <br />
                <span className="text-primary">Results, automated.</span>
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto scroll-reveal" style={{ animationDelay: '1000ms' }}>
                Chat, voice, outreach, leads, and social — built to run your operations at scale.
              </p>
              <div className="scroll-reveal" style={{ animationDelay: '1500ms' }}>
                <Button asChild size="lg" className="text-lg px-8 py-6">
                  <Link to="/en/services">Explore Services</Link>
                </Button>
              </div>
            </div>
          </section>

          {/* Industries We Serve - Inline Emoji Row */}
          <section className="bg-background py-24">
            <div className="container mx-auto px-4">
              <div className="text-center mb-12">
                <h2 className="text-4xl font-heading font-bold uppercase mb-8 scroll-reveal">
                  Industries We Serve
                </h2>
              </div>
              <div className="flex justify-center items-center gap-12 flex-wrap max-w-5xl mx-auto">
                {[
                  { emoji: '🎓', label: 'Education', anchor: 'education' },
                  { emoji: '🏢', label: 'Real Estate', anchor: 'real-estate' },
                  { emoji: '⚕️', label: 'Healthcare', anchor: 'healthcare' },
                  { emoji: '🛒', label: 'E-commerce', anchor: 'ecommerce' },
                  { emoji: '💼', label: 'Professional Services', anchor: 'professional-services' },
                ].map((industry, index) => (
                  <Link
                    key={industry.label}
                    to={`/en/industries#${industry.anchor}`}
                    className="flex flex-col items-center justify-center min-w-[100px] min-h-[100px] cursor-pointer group scroll-reveal transition-all duration-200 hover:scale-105 focus:outline-2 focus:outline-primary active:scale-95 active:shadow-[0_0_20px_rgba(0,206,209,0.4)]"
                    style={{ animationDelay: `${index * 100}ms` }}
                    aria-label={`Go to ${industry.label} section`}
                  >
                    <span className="text-6xl mb-2">{industry.emoji}</span>
                    <p className="text-lg font-semibold text-foreground text-center transition-colors duration-200 group-hover:text-primary">
                      {industry.label}
                    </p>
                  </Link>
                ))}
              </div>
            </div>
          </section>

          {/* Services Overview */}
          <section className="container mx-auto px-4 py-24">
            <div className="text-center mb-16 scroll-reveal">
              <h2 className="text-4xl font-heading font-bold uppercase mb-4">
                Our Services
              </h2>
              <p className="text-lg" style={{ color: '#666666' }}>
                Comprehensive AI automation solutions for modern businesses.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
              {services.map((service, index) => {
                const IconComponent = service.icon;
                return (
                  <Link
                    key={service.title}
                    to={service.href}
                    className="group bg-white p-8 rounded-2xl border border-border shadow-[0_4px_12px_rgba(0,0,0,0.05)] hover:shadow-[0_4px_16px_rgba(0,206,209,0.25)] service-card-hop active:scale-[0.97] scroll-reveal flex items-start gap-4 focus:outline-2 focus:outline-primary focus:ring-2 focus:ring-primary transition-transform duration-150"
                    style={{ animationDelay: `${index * 100}ms` }}
                    aria-label={`Learn more about ${service.title}`}
                  >
                    <div className="flex-shrink-0">
                      <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center">
                        <IconComponent className="w-8 h-8 text-primary" strokeWidth={1.5} />
                      </div>
                    </div>
                    <div className="flex-1 min-w-0 pt-1">
                      <h3 className="font-heading font-bold text-lg mb-1 text-foreground group-hover:text-primary transition-colors duration-200">{service.title}</h3>
                      <p className="text-sm line-clamp-1" style={{ color: '#666666' }}>{service.shortDescription}</p>
                    </div>
                    <div className="flex-shrink-0 text-primary group-hover:translate-x-1 transition-transform duration-200 pt-1">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </div>
                  </Link>
                );
              })}
            </div>
          </section>

          {/* Core Values */}
          <section className="container mx-auto px-4 py-16">
            <h2 className="text-4xl font-heading font-bold uppercase text-center mb-12 scroll-reveal">
              Our Core Values
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              <div className="bg-card p-8 rounded-2xl border border-border shadow-sm card-hover-effect scroll-reveal">
                <div className="flex justify-center mb-4">
                  <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center">
                    <Shield className="w-7 h-7 text-primary" strokeWidth={1.5} />
                  </div>
                </div>
                <h3 className="text-xl font-heading font-bold uppercase mb-3 text-center hover-text">Privacy</h3>
                <p className="text-muted-foreground text-center">
                  We protect data and design for compliance by default.
                </p>
              </div>
              <div className="bg-card p-8 rounded-2xl border border-border shadow-sm card-hover-effect scroll-reveal">
                <div className="flex justify-center mb-4">
                  <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center">
                    <Gauge className="w-7 h-7 text-primary" strokeWidth={1.5} />
                  </div>
                </div>
                <h3 className="text-xl font-heading font-bold uppercase mb-3 text-center hover-text">Performance</h3>
                <p className="text-muted-foreground text-center">
                  Fast, scalable systems with measurable uptime and latency.
                </p>
              </div>
              <div className="bg-card p-8 rounded-2xl border border-border shadow-sm card-hover-effect scroll-reveal">
                <div className="flex justify-center mb-4">
                  <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center">
                    <Eye className="w-7 h-7 text-primary" strokeWidth={1.5} />
                  </div>
                </div>
                <h3 className="text-xl font-heading font-bold uppercase mb-3 text-center hover-text">Clarity</h3>
                <p className="text-muted-foreground text-center">
                  Transparent logic, clean handoff, simple controls.
                </p>
              </div>
            </div>
          </section>
        </main>
        <Footer lang="en" />
      </div>
  );
};

export default Home;
