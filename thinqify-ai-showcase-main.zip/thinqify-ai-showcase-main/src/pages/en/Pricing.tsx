import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';

import { useScrollReveal } from '@/hooks/useScrollReveal';
import { Rocket, RefreshCw, Server, Wrench, TrendingUp, Shield, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Pricing = () => {
  useScrollReveal();

  useEffect(() => {
    document.documentElement.lang = 'en';
  }, []);

  const engagementModels = [
    {
      icon: Rocket,
      title: 'One-Time Project',
      tagline: 'Build & Bounce',
      description: 'Fixed scope with clear deliverables.',
      includes: [
        'Defined project scope and timeline',
        'Clear deliverable milestones',
        'Training and documentation included',
        'Post-launch support period',
        'Knowledge transfer to your team',
      ],
      bestFor: 'Businesses with internal technical resources ready to take over.',
    },
    {
      icon: RefreshCw,
      title: 'Monthly Retainer',
      tagline: 'Build & Maintain',
      description: 'Ongoing updates and improvements within defined boundaries.',
      includes: [
        'Monthly maintenance windows',
        'Feature enhancements and updates',
        'Performance monitoring',
        'Bug fixes and optimizations',
        'Regular strategy reviews',
      ],
      bestFor: 'Organizations wanting continuous improvement while retaining operational control.',
    },
    {
      icon: Server,
      title: 'Fully Managed & Hosted',
      tagline: 'Maintain, Improve & Host',
      description: 'We operate the full stack for you under fixed or usage-based terms.',
      includes: [
        'Complete operational management',
        'Infrastructure hosting and monitoring',
        'Continuous optimization',
        'Proactive issue resolution',
        'Dedicated support team',
        'Regular performance reports',
      ],
      bestFor: 'Clients seeking a hands-off solution with guaranteed uptime and performance.',
    },
  ];

  const maintenanceTiers = [
    {
      icon: Wrench,
      title: 'Basic Maintenance',
      description: 'Bug fixes and uptime care.',
      includes: [
        'Critical bug fixes',
        'Security patches',
        'Uptime monitoring',
        'Basic support during business hours',
      ],
    },
    {
      icon: TrendingUp,
      title: 'Maintenance + Improvement',
      description: 'Fixes plus scheduled enhancements.',
      includes: [
        'All Basic Maintenance features',
        'Monthly feature enhancements',
        'Performance optimizations',
        'Priority support',
        'Quarterly strategy sessions',
      ],
    },
    {
      icon: Shield,
      title: 'Maintain, Improve & Host',
      description: 'All-in, fully managed maintenance.',
      includes: [
        'All Maintenance + Improvement features',
        'Infrastructure management',
        'Proactive monitoring and alerts',
        '24/7 support coverage',
        'Dedicated account manager',
      ],
    },
  ];

  return (
    <div className="min-h-screen">
        <Header lang="en" />
        <main className="container mx-auto px-4 pt-32 pb-24">
          {/* Hero Section */}
          <div className="text-center mb-20 scroll-reveal">
            <h1 className="text-5xl font-heading font-bold uppercase mb-4">
              Engagement & <span className="text-primary">Maintenance</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Flexible engagement models designed to fit your operational needs and technical capabilities.
            </p>
          </div>

          {/* Engagement Models Section */}
          <section className="mb-24">
            <h2 className="text-3xl font-heading font-bold uppercase text-center mb-12 scroll-reveal">
              Engagement Models
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {engagementModels.map((model, index) => {
                const IconComponent = model.icon;
                return (
                  <div
                    key={model.title}
                    className="bg-card p-8 rounded-2xl border border-border card-hover-effect scroll-reveal"
                    style={{ animationDelay: `${index * 80}ms` }}
                  >
                    <IconComponent className="w-12 h-12 text-primary mb-4" />
                    <h3 className="text-2xl font-heading font-bold uppercase mb-2 hover-text">{model.title}</h3>
                    <p className="text-primary font-semibold mb-3">{model.tagline}</p>
                    <p className="text-muted-foreground mb-6">{model.description}</p>
                    
                    <div className="mb-6">
                      <p className="font-semibold mb-3 uppercase text-sm">Includes:</p>
                      <ul className="space-y-2">
                        {model.includes.map((item) => (
                          <li key={item} className="flex items-start gap-2">
                            <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                            <span className="text-sm">{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    <p className="text-sm italic text-muted-foreground border-t border-border pt-4">
                      <span className="font-semibold not-italic">Best for:</span> {model.bestFor}
                    </p>
                  </div>
                );
              })}
            </div>
          </section>

          {/* Maintenance Tiers Section */}
          <section className="mb-24">
            <h2 className="text-3xl font-heading font-bold uppercase text-center mb-12 scroll-reveal">
              Maintenance Tiers
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {maintenanceTiers.map((tier, index) => {
                const IconComponent = tier.icon;
                return (
                  <div
                    key={tier.title}
                    className="bg-card p-8 rounded-2xl border border-border card-hover-effect scroll-reveal"
                    style={{ animationDelay: `${index * 80}ms` }}
                  >
                    <IconComponent className="w-12 h-12 text-primary mb-4" />
                    <h3 className="text-2xl font-heading font-bold uppercase mb-2 hover-text">{tier.title}</h3>
                    <p className="text-muted-foreground mb-6">{tier.description}</p>
                    
                    <div>
                      <p className="font-semibold mb-3 uppercase text-sm">Includes:</p>
                      <ul className="space-y-2">
                        {tier.includes.map((item) => (
                          <li key={item} className="flex items-start gap-2">
                            <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                            <span className="text-sm">{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          {/* CTA Footer */}
          <div className="text-center scroll-reveal">
            <p className="text-xl mb-6">Ready to explore how we can work together?</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link to="/en/services">
                <Button size="lg" className="min-w-[200px]">
                  Explore Services
                </Button>
              </Link>
              <Link to="/en/about">
                <Button size="lg" variant="outline" className="min-w-[200px]">
                  About Thinqify
                </Button>
              </Link>
            </div>
          </div>
        </main>
        <Footer lang="en" />
      </div>
  );
};

export default Pricing;
