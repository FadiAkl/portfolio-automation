import { Link } from 'react-router-dom';

interface FooterProps {
  lang: 'en' | 'fr';
}

const Footer = ({ lang }: FooterProps) => {
  const translations = {
    en: {
      copyright: '© 2025 Thinqify.',
      contact: 'Contact:',
    },
    fr: {
      copyright: '© 2025 Thinqify.',
      contact: 'Contact :',
    },
  };

  const t = translations[lang];

  return (
    <footer className="bg-background py-12 mt-24">
      <div className="container mx-auto px-4">
        <div className="text-center text-sm text-muted-foreground space-y-2">
          <p>
            {t.contact}{' '}
            <a 
              href="mailto:fadi@thinqify.com" 
              className="text-primary hover:underline focus:outline-2 focus:outline-primary"
            >
              fadi@thinqify.com
            </a>
          </p>
          <p>{t.copyright}</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
