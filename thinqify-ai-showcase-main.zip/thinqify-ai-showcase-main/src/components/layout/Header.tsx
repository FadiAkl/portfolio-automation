import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

interface HeaderProps {
  lang: 'en' | 'fr';
}

const Header = ({ lang }: HeaderProps) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const translations = {
    en: {
      home: 'Home',
      services: 'Services',
      industries: 'Industries',
      pricing: 'Engagement & Maintenance',
      about: 'About',
      faq: 'FAQ',
    },
    fr: {
      home: 'Accueil',
      services: 'Services',
      industries: 'Industries',
      pricing: 'Engagement & Maintenance',
      about: 'À Propos',
      faq: 'FAQ',
    },
  };

  const t = translations[lang];
  const otherLang = lang === 'en' ? 'fr' : 'en';
  const currentPath = location.pathname.replace(/^\/(en|fr)/, '');

  const navLinks = [
    { href: `/${lang}`, label: t.home },
    { href: `/${lang}/services`, label: t.services },
    { href: `/${lang}/industries`, label: t.industries },
    { href: `/${lang}/engagement-maintenance`, label: t.pricing },
    { href: `/${lang}/about`, label: t.about },
    { href: `/${lang}/faq`, label: t.faq },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-black/5 transition-all duration-300">
      <nav className={`container mx-auto px-4 transition-all duration-300 ${isScrolled ? 'py-3' : 'py-4'}`}>
        <div className="flex items-center justify-center gap-8">
          {/* Desktop Navigation - Centered */}
          <div className="hidden lg:flex items-center gap-8">
            <Link to={`/${lang}`} className="logo-wordmark text-xl uppercase tracking-tight">
              Thinqify
            </Link>
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                className="text-sm font-medium text-foreground transition-colors relative after:content-[''] after:absolute after:w-full after:scale-x-0 after:h-0.5 after:bottom-0 after:left-0 after:bg-primary after:origin-bottom-right after:transition-transform after:duration-300 hover:after:scale-x-100 hover:after:origin-bottom-left focus:outline-2 focus:outline-primary"
              >
                {link.label}
              </Link>
            ))}
            <Link
              to={`/${otherLang}${currentPath || ''}`}
              className="text-sm font-bold uppercase text-primary hover:underline focus:outline-2 focus:outline-primary"
            >
              {otherLang.toUpperCase()}
            </Link>
          </div>
          
          {/* Mobile Layout - Keep original left/right alignment */}
          <div className="flex lg:hidden items-center justify-between w-full">
            <Link to={`/${lang}`} className="logo-wordmark text-2xl uppercase tracking-tight">
              Thinqify
            </Link>
            <div className="flex items-center gap-4">
              <Link
                to={`/${otherLang}${currentPath || ''}`}
                className="text-sm font-bold uppercase text-primary"
              >
                {otherLang.toUpperCase()}
              </Link>
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2"
                aria-label="Toggle menu"
              >
                {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>


        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="lg:hidden mt-4 pb-4 flex flex-col gap-4">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="text-sm font-medium transition-colors hover:text-primary"
              >
                {link.label}
              </Link>
            ))}
          </div>
        )}
      </nav>
    </header>
  );
};

export default Header;
