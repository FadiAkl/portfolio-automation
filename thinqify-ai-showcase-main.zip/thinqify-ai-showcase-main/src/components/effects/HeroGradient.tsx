import { useEffect, useRef } from 'react';

const HeroGradient = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Set canvas size
    const setCanvasSize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    setCanvasSize();
    window.addEventListener('resize', setCanvasSize);

    // Create gradient blobs
    const blobs = [
      { x: 0.2, y: 0.3, radius: 150, speedX: 0.0003, speedY: 0.0002 },
      { x: 0.8, y: 0.6, radius: 200, speedX: -0.0002, speedY: 0.0003 },
      { x: 0.5, y: 0.8, radius: 180, speedX: 0.0002, speedY: -0.0002 },
    ];

    let animationId: number;
    let lastTime = Date.now();

    const animate = () => {
      if (prefersReducedMotion) return;

      const currentTime = Date.now();
      const deltaTime = currentTime - lastTime;
      lastTime = currentTime;

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      blobs.forEach((blob) => {
        // Update position
        blob.x += blob.speedX * deltaTime;
        blob.y += blob.speedY * deltaTime;

        // Bounce off edges
        if (blob.x < 0 || blob.x > 1) blob.speedX *= -1;
        if (blob.y < 0 || blob.y > 1) blob.speedY *= -1;

        // Keep within bounds
        blob.x = Math.max(0, Math.min(1, blob.x));
        blob.y = Math.max(0, Math.min(1, blob.y));

        // Draw gradient blob
        const gradient = ctx.createRadialGradient(
          blob.x * canvas.width,
          blob.y * canvas.height,
          0,
          blob.x * canvas.width,
          blob.y * canvas.height,
          blob.radius
        );
        gradient.addColorStop(0, 'rgba(0, 206, 209, 0.08)');
        gradient.addColorStop(1, 'rgba(0, 206, 209, 0)');

        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      });

      animationId = requestAnimationFrame(animate);
    };

    if (!prefersReducedMotion) {
      animate();
    } else {
      // Static render for reduced motion
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      blobs.forEach((blob) => {
        const gradient = ctx.createRadialGradient(
          blob.x * canvas.width,
          blob.y * canvas.height,
          0,
          blob.x * canvas.width,
          blob.y * canvas.height,
          blob.radius
        );
        gradient.addColorStop(0, 'rgba(0, 206, 209, 0.08)');
        gradient.addColorStop(1, 'rgba(0, 206, 209, 0)');

        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      });
    }

    return () => {
      window.removeEventListener('resize', setCanvasSize);
      if (animationId) cancelAnimationFrame(animationId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none"
      style={{ opacity: 0.6 }}
    />
  );
};

export default HeroGradient;
