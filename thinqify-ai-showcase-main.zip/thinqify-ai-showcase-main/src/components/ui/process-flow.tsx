import { LucideIcon } from 'lucide-react';

interface FlowStep {
  icon: LucideIcon;
  label: string;
}

interface ProcessFlowProps {
  steps: FlowStep[];
}

const ProcessFlow = ({ steps }: ProcessFlowProps) => {
  return (
    <div className="relative bg-gradient-to-r from-primary/5 to-primary/10 rounded-2xl p-8 my-12 scroll-reveal">
      <div className="flex items-center justify-center gap-4 md:gap-8 flex-wrap md:flex-nowrap">
        {steps.map((step, index) => {
          const Icon = step.icon;
          return (
            <div key={index} className="flex items-center gap-4 md:gap-8">
              <div 
                className="flex flex-col items-center scroll-reveal"
                style={{ animationDelay: `${index * 80}ms` }}
              >
                <div className="bg-background rounded-xl shadow-lg p-6 w-40 flex flex-col items-center gap-3 hover:shadow-xl transition-shadow">
                  <div className="bg-primary/10 rounded-full p-3">
                    <Icon className="text-primary" size={32} strokeWidth={1.5} />
                  </div>
                  <p className="text-sm font-semibold text-center text-foreground">
                    {step.label}
                  </p>
                </div>
              </div>
              {index < steps.length - 1 && (
                <div 
                  className="hidden md:block w-12 h-0.5 bg-gradient-to-r from-primary to-primary/50 scroll-reveal"
                  style={{ animationDelay: `${(index * 80) + 40}ms` }}
                />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ProcessFlow;
