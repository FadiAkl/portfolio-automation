import { Link } from 'react-router-dom';
import { LucideIcon } from 'lucide-react';

interface ServiceCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  href: string;
}

const ServiceCard = ({ title, description, icon: Icon, href }: ServiceCardProps) => {
  return (
    <Link
      to={href}
      className="block p-6 bg-card border-2 border-border rounded-2xl card-hover-effect scroll-reveal"
      style={{
        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.05)',
      }}
    >
      <div className="mb-4 text-primary transition-colors duration-200">
        <Icon size={40} strokeWidth={1.5} />
      </div>
      <h3 className="text-xl font-heading font-bold mb-2 uppercase transition-colors duration-200">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </Link>
  );
};

export default ServiceCard;
